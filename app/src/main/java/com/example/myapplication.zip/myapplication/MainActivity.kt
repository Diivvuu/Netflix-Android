package com.example.myapplication

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { BottomNavigationBar() }
                ) { innerPadding ->
                    HomeScreen(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun HeroBanner(title: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(Color.DarkGray)
    ) {
        // Fake background image
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(randomColor())
        )

        // Gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black),
                        startY = 100f
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text(text = title, color = Color.White, fontSize = 24.sp, modifier = Modifier.padding(bottom = 8.dp))
            Row {
                Button(
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                ) {
                    Text("Play", color = Color.Black)
                }
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedButton(onClick = {}) {
                    Text("Add to List", color = Color.White)
                }
            }
        }
    }
}


@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    val featuredMovies = listOf("Avatar", "Stranger Things", "Inception", "Interstellar", "Money Heist")
    val dummyMovies = List(15) { i -> "Movie Title #${i + 1}" }
    var currentIndex by remember { mutableStateOf(0) }

    // Auto-scroll logic
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(4000)
            currentIndex = (currentIndex + 1) % featuredMovies.size
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        item {
            HeroBanner(title = featuredMovies[currentIndex])
        }
        item {
            SectionTitle(title = "Channels")
            HorizontalMovieList(
                movies = dummyMovies.take(5),
                itemWidth = 120.dp,
                itemHeight = 160.dp
            )
        }
        item {
            SectionTitle(title = "Continue Watching")
            HorizontalMovieList(
                movies = dummyMovies.take(10),
                itemWidth = 200.dp,
                itemHeight = 120.dp
            )
        }
        item {
            SectionTitle(title = "Top 10")
            HorizontalMovieList(
                movies = dummyMovies.take(7),
                itemWidth = 160.dp,
                itemHeight = 240.dp
            )
        }
    }
}


@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        color = Color.White,
        fontSize = 20.sp,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
fun HorizontalMovieList(movies: List<String>, itemWidth: Dp, itemHeight: Dp) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(movies) { movie ->
            MovieItem(title = movie, width = itemWidth, height = itemHeight)
        }
    }
}

@Composable
fun MovieItem(title: String, width: Dp, height: Dp) {
    val context = LocalContext.current
    var isClicked by remember { mutableStateOf(false) }

    val backgroundColor by animateColorAsState(
        targetValue = if (isClicked) Color.Green else Color.DarkGray,
        label = "cardAnimation"
    )

    Column(
        modifier = Modifier
            .width(width)
            .background(backgroundColor, shape = MaterialTheme.shapes.medium)
            .clickable {
                isClicked = !isClicked
                Toast
                    .makeText(context, "Clicked on \"$title\"", Toast.LENGTH_SHORT)
                    .show()
            }
    ) {
        Box(
            modifier = Modifier
                .height(height)
                .fillMaxWidth()
                .background(randomColor()) // visually distinctive
        )
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(4.dp)
        )
    }
}

fun randomColor(): Color {
    val colors = listOf(
        Color(0xFF6C5CE7),
        Color(0xFF00CEC9),
        Color(0xFFFF7675),
        Color(0xFFFFD32A),
        Color(0xFF0984E3),
        Color(0xFF74B9FF)
    )
    return colors.random()
}

@Composable
fun BottomNavigationBar() {
    NavigationBar(containerColor = Color.Black) {
        NavigationBarItem(
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home") },
            selected = true,
            onClick = { }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.List, contentDescription = "Products") },
            label = { Text("Products") },
            selected = false,
            onClick = { }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Star, contentDescription = "My Rewards") },
            label = { Text("My Rewards") },
            selected = false,
            onClick = { }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    MyApplicationTheme {
        Scaffold(
            bottomBar = { BottomNavigationBar() }
        ) { innerPadding ->
            HomeScreen(Modifier.padding(innerPadding))
        }
    }
}
